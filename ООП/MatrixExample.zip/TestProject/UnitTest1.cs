namespace TestProject
{
    [TestClass]
    public class UnitTest
    {
        SquareMatrix testMatrix ;
        public UnitTest()
        {
        testMatrix = new SquareMatrix(2);
            testMatrix[0,0] = 1;
            testMatrix[0, 1] = 2;
            testMatrix[1, 0] = 3;
            testMatrix[1, 1] = 4;
        }

        [TestMethod]
        public void LMultXSize2()
        {
            double[] res = new double[2];
            testMatrix.LMult([1, 2], res);
            Assert.AreEqual(2, res.Length);
            Assert.AreEqual(3, res[1],1e-15);
            Assert.AreEqual(0, res[0], 1e-15);
        }
        [TestMethod]
        public void UMultXSize2()
        {
            double[] res = new double[2];
            testMatrix.UMult([1, 2], res);
            Assert.AreEqual(2, res.Length);
            Assert.AreEqual(4, res[0], 1e-15);
            Assert.AreEqual(0, res[1], 1e-15);
        }
        [TestMethod]
        public void MultXSize2()
        {
            var res = testMatrix*[1, 2];
            Assert.AreEqual(2, res.Length);
            Assert.AreEqual(5, res[0], 1e-15);
            Assert.AreEqual(11, res[1], 1e-15);
        }
    }
}